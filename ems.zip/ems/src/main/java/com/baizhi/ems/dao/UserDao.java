package com.baizhi.ems.dao;

import com.baizhi.ems.entity.User;

public interface UserDao {
    //保存用户
    void Save(User user);
}
